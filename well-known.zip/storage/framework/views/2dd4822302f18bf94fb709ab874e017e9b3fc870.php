                      <div class="form-group row">
                        <label for="name" class="col-sm-2 col-form-label">اسم المستخدم</label>
                        <div class="col-sm-4">
                          <input type="text" name="name" class="form-control cairo" id="name" placeholder=" اسم المستخدم" value="<?php echo e(isset($row)? $row->name : old('name')); ?>" >
                            
                          
                        </div>
                        <label for="email" class="col-sm-2 col-form-label">البريد الالكتروني</label>
                        <div class="col-sm-4">
                          <input type="email" name="email" id="email" class="form-control cairo" placeholder=" البريد الالكتروني" value="<?php echo e(isset($row)? $row->email : old('email')); ?>">
                        </div>
                        
                      </div>
                      <?php if($errors->any()): ?>
                        <div class=" row">
                            
                                <div class="col-sm-2"></div>
                                <div class="col-sm-4  text-center" >
                                  <?php if($errors->has('name')): ?>
                                    <p class="pt-2 pb-2  bg-danger" style="border-radius:50px !important"><?php echo e($errors->first('name')); ?></p>
                                  <?php endif; ?>
                                </div>
                            
                                <div class="col-sm-2"></div>
                                  <div class="col-sm-4  text-center" >
                                    <?php if($errors->has('email') ): ?>
                                      <p class="pt-2 pb-2  bg-danger" style="border-radius:50px !important"><?php echo e($errors->first('email')); ?></p>
                                    <?php endif; ?>
                                  </div>
                                
                            
                        </div>
                      <?php endif; ?>
                        
                      
                      
                      
                     
                      
                      
                      
                      
                     
                      
                      
                      
                      
                     
                      
                      <?php /**PATH C:\Mohamed\im\GoldenSSM\resources\views/admin/user/form.blade.php ENDPATH**/ ?>