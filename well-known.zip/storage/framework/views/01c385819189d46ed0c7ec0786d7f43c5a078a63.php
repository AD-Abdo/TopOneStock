<!-- content-wrapper ends -->
        <footer class="footer">
          <div class=" text-center">
            <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">كل الحقوق محفوظة لــ ©  <a
                href="<?php echo e(route('home')); ?>" target="_blank">GoldenSSM</a></span>
          </div>
        </footer>
<?php /**PATH /home/goldenss/public_html/resources/views/admin/layouts/footer.blade.php ENDPATH**/ ?>