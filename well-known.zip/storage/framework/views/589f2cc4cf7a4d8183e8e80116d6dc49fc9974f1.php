

 
  
<?php 
  $title = 'جولدن - لوحة التحكم - اضافة مشرف جديد';
?> 

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper ">
            <div class="page-header">
              <h3 class="page-title">جدول المشرفين / اضافة مشرف جديد</h3>
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="<?php echo e(route('admin.user.index')); ?>" class="btn btn-success pt-2 pl-3 pb-2"> <i class="mdi mdi-arrow-left  d-md-block"></i> </a></li>
                </ol>
              </nav>
            </div>
            <div class="row">
              <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    
                    <form class="forms-sample" action="<?php echo e(route('admin.user.store')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>
                        <?php echo $__env->make('admin.user.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="form-group row">
                        <label for="password" class="col-sm-2 col-form-label">كلمة المرور</label>
                        <div class="col-sm-4">
                          <input type="password" name="password" class="form-control cairo" id="password" placeholder="كلمة مرور المستخدم"  >
                            
                          
                        </div>
                        <label for="password_confirmation" class="col-sm-2 col-form-label">تاكيد كلمة المرور</label>
                        <div class="col-sm-4">
                          <input type="password" name="password_confirmation" id="password_confirmation" class="form-control cairo"placeholder="تاكيد كلمة مرور المسخدم">
                        </div>
                        
                      </div>
                      <?php if($errors->any()): ?>
                        <div class=" row">
                            
                                <div class="col-sm-2"></div>
                                <div class="col-sm-4  text-center" >
                                  <?php if($errors->has('password')): ?>
                                    <p class="pt-2 pb-2  bg-danger" style="border-radius:50px !important"><?php echo e($errors->first('password')); ?></p>
                                  <?php endif; ?>
                                </div>
                            
                                <div class="col-sm-2"></div>
                                  <div class="col-sm-4  text-center" >
                                    <?php if($errors->has('confirmPassword') ): ?>
                                      <p class="pt-2 pb-2  bg-danger" style="border-radius:50px !important"><?php echo e($errors->first('confirmPassword')); ?></p>
                                    <?php endif; ?>
                                  </div>
                                
                            
                        </div>
                      <?php endif; ?>
                        <div class="form-group row">
                        <label for="name" class="col-sm-2 col-form-label">الرتبة</label>
                        <div class="col-sm-10">
                                <select class="form-control cairo" name="role">
                                    <option selected disabled>اختر الرتبة</option>
                                    <?php if(isset($row)): ?>
                                      <?php if($row->role == 1): ?>
                                        <option value="2">مشرف</option>
                                        <option value="1" selected>مدير</option>
                                      <?php elseif($row->role==2): ?>
                                        <option value="2" selected>مشرف</option>
                                        <option value="1" >مدير</option>
                                        <?php else: ?>
                                        <option value="2">مشرف</option>
                                        <option value="1" >مدير</option>
                                      <?php endif; ?>
                                    <?php else: ?>
                                       <option value="2">مشرف</option>
                                      <option value="1" >مدير</option>
                                    <?php endif; ?>
                                </select>
                                
                            
                          
                        </div>
                        
                        
                      </div>
                      <?php if($errors->any()): ?>
                        <div class=" row">
                            
                                <div class="col-sm-2"></div>
                                <div class="col-sm-10  text-center" >
                                  <?php if($errors->has('role')): ?>
                                    <p class="pt-2 pb-2  bg-danger" style="border-radius:50px !important"><?php echo e($errors->first('role')); ?></p>
                                  <?php endif; ?>
                                </div>
                            
                                
                            
                        </div>
                      <?php endif; ?>
                        <div class="form-group row">
                        
                        <label for="image" class="col-sm-2 col-form-label">الصورة</label>
                        <div class="col-sm-10">
                          <input type="file" accept="image/*" name="image"   class="form-control cairo" id="image" placeholder="صورة">
                        </div>
                      </div>
                      <?php if($errors->any()): ?>
                        <div class=" row">
                            
                                
                              
                            
                                <div class="col-sm-2"></div>
                                <div class="col-sm-10  text-center" >
                                  <?php if($errors->has('image') ): ?>
                                    <p class="pt-2 pb-2  bg-danger" style="border-radius:50px !important"><?php echo e($errors->first('image')); ?></p>
                                  <?php endif; ?>
                                </div>
                            
                        </div>
                      <?php endif; ?>
                      
                        <div class=" row  w-100 mt-4">
                            <div class="col-md-4">
                            </div>
                            <div class="col-md-4">

                                <input type="submit" class="text-center btn btn-primary w-100 cairo" value="اضافة">
                            </div>
                            <div class="col-md-4">
                            </div>

                        </div>
                    </form>
                  </div>
                </div>
              </div>
              
            </div>
          </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/goldenss/public_html/resources/views/admin/user/create.blade.php ENDPATH**/ ?>