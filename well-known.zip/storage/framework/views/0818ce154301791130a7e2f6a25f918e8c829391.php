<?php $__env->startPush('css'); ?>
    <style>
        input{
            background-color:#2A3038 !important
        }    
    </style>
<?php $__env->stopPush(); ?>

 
  
<?php 
  $title = 'جولدن - لوحة التحكم - البروفايل ';
?> 

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper ">
            <div class="page-header">
              <h3 class="page-title">تعديل بياناتي الشخصية </h3>
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="<?php echo e(route('admin.home')); ?>" class="btn btn-success pt-2 pl-3 pb-2"> <i class="mdi mdi-arrow-left  d-md-block"></i> </a></li>
                </ol>
              </nav>
            </div>
            <div class="row">
              <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">

                    
                    
                    <form class="forms-sample" enctype="multipart/form-data" method="POST" action="<?php echo e(route('admin.profile.update')); ?>">
                      <?php echo csrf_field(); ?>
                      <?php echo method_field('put'); ?>

                        
                    <div class="form-group row">
                        <label for="name" class="col-sm-2 col-form-label">الاسم</label>
                        <div class="col-sm-4">
                          <input type="text" name="name" class="form-control cairo" id="name" placeholder=" الاسم" value="<?php echo e(Auth::user()->name); ?>" >
                            
                          
                        </div>
                        <label for="email" class="col-sm-2 col-form-label">البريد الالكتروني</label>
                        <div class="col-sm-4">
                          <input type="email" name="email" id="email" step="any" class="form-control cairo" id="email" placeholder=" البريد الالكتروني" value="<?php echo e(Auth::user()->email); ?>">
                        </div>
                        
                      </div>
                      <?php if($errors->any()): ?>
                        <div class=" row">
                            
                                <div class="col-sm-2"></div>
                                <div class="col-sm-4  text-center" >
                                  <?php if($errors->has('name')): ?>
                                    <p class="pt-2 pb-2  bg-danger" style="border-radius:50px !important"><?php echo e($errors->first('name')); ?></p>
                                  <?php endif; ?>
                                </div>
                            
                                <div class="col-sm-2"></div>
                                  <div class="col-sm-4  text-center" >
                                    <?php if($errors->has('email') ): ?>
                                      <p class="pt-2 pb-2  bg-danger" style="border-radius:50px !important"><?php echo e($errors->first('email')); ?></p>
                                    <?php endif; ?>
                                  </div>
                                
                            
                        </div>
                      <?php endif; ?>
                      <?php if(Auth::user()->image != null): ?>

                        <div class="form-group row">
                        <label for="image" class="col-sm-2 col-form-label">الصورة</label>
                        <div class="col-sm-4">
                          <input type="file" accept="image/*" name="image"   class="form-control cairo" id="image" placeholder="صورة">
                        </div>
                        <div class="col-sm-6 text-center">
                          <img class="img-lg rounded-circle mb-3" src="/user/<?php echo e(Auth::user()->image); ?>">
                        </div>
                      </div>
                       <?php if($errors->any()): ?>
                        <div class=" row">
                            
                                <div class="col-sm-2"></div>
                                <div class="col-sm-4  text-center" >
                                  <?php if($errors->has('image') ): ?>
                                    <p class="pt-2 pb-2  bg-danger" style="border-radius:50px !important"><?php echo e($errors->first('image')); ?></p>
                                  <?php endif; ?>
                                </div>
                                <div class="col-sm-6"></div>
                            
                        </div>
                      <?php endif; ?>
                      
                    <?php else: ?>
                    <div class="form-group row">
                        
                        <label for="image" class="col-sm-2 col-form-label">الصورة</label>
                        <div class="col-sm-10">
                          <input type="file" accept="image/*" name="image"   class="form-control cairo" id="image" placeholder="صورة">
                        </div>
                        
                      </div>
                       <?php if($errors->any()): ?>
                        <div class=" row">
                            
                                
                              
                            
                                <div class="col-sm-2"></div>
                                <div class="col-sm-10  text-center" >
                                  <?php if($errors->has('image') ): ?>
                                    <p class="pt-2 pb-2  bg-danger" style="border-radius:50px !important"><?php echo e($errors->first('image')); ?></p>
                                  <?php endif; ?>
                                </div>
                            
                        </div>
                      <?php endif; ?>
                    <?php endif; ?>
                   
                      <div class=" row  w-100 mt-4">
                            <div class="col-md-4">
                            </div>
                            <div class="col-md-4">

                                <input type="submit" class="text-center btn btn-primary w-100 cairo" value="تعديل">
                            </div>
                            <div class="col-md-4">
                            </div>

                        </div>
                    </form>
                  </div>
                </div>
              </div>
              
            </div>
          </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
    document.getElementById("email").disabled = true;
    
</script>
<?php $__env->stopPush(); ?>




<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/goldenss/public_html/resources/views/admin/profile/edit.blade.php ENDPATH**/ ?>