



<?php 
//active item
    $title = 'تسجيل جديد';
    $description ='تسجيل مستخدم جديد فى موقع شركة توب وان للتوصيات و الاسهم السعودية';
    $item[0] = '';
    $item[1] = '';
    $item[2] = '';
    $item[3] = '';
    $item[4] = '';


?>
<?php $__env->startSection('content'); ?>

<main class="tasgel-gaded">
      <h1 class="text-center animate__ animate__bounceInDown animated" style="visibility: visible; animation-name: bounceInDown;">تســـجيل جديــــد</h1>
      <div class="container">
        <div class="form-content">
          <div class="theForm">
            <form method="POST" action="<?php echo e(route('register')); ?>">
              <?php echo csrf_field(); ?>
              <?php echo method_field('POST'); ?>
              <div class="form-group">
                <label for="exampleInputName">الاســــــــم <span>*</span></label>
                <input name="name" value="<?php echo e(old('name')); ?>" type="text" class="form-control" id="exampleInputName" placeholder="أدخل إسـمك" aria-describedby="nameHelp">
              </div>
              <?php if($errors->any()): ?>
                <?php if($errors->has('name')): ?>
                  <div class="form-group bg-danger text-light pt-2 pb-2 text-center">
                    <?php echo e($errors->first('name')); ?>

                  </div>
                <?php endif; ?>
              <?php endif; ?>
              <div class="form-group">
                <label for="exampleInputEmail">البـــريد الإلكترونى <span>*</span></label>
                <input type="text" value="<?php echo e(old('email')); ?>" name="email" class="form-control" id="exampleInputEmail" placeholder="أدخل البريد الإلكترونى">
              </div>
              <?php if($errors->any()): ?>
                <?php if($errors->has('email')): ?>
                  <div class="form-group bg-danger text-light pt-2 pb-2 text-center">
                    <?php echo e($errors->first('email')); ?>

                  </div>
                <?php endif; ?>
              <?php endif; ?>
              <div class="form-group">
                <label for="exampleInputPhone">رقـــم الهـــاتـــف <span>*</span></label>
                <input type="text" value="<?php echo e(old('phone')); ?>" name="phone" class="form-control" id="exampleInputPhone" placeholder="أدخل رقم هاتفك" aria-describedby="emailHelp">
              </div>
              <?php if($errors->any()): ?>
                <?php if($errors->has('phone')): ?>
                  <div class="form-group bg-danger text-light pt-2 pb-2 text-center">
                    <?php echo e($errors->first('phone')); ?>

                  </div>
                <?php endif; ?>
              <?php endif; ?>
              <div class="form-group">
                <label for="exampleFormControlTextarea1">إختـــر الدولــة <span>*</span></label>
                <select class="form-control" name="country">
                  <option disabled selected>إختر الدولة</option>
                  <?php if(old('country')=="مصر"): ?>
                    <option selected value="مصر">مـــــــصـــــر</option>
                  <?php else: ?>
                    <option  value="مصر">مـــــــصـــــر</option>
                  <?php endif; ?>
                  <?php if(old('country')=="السعودية"): ?>
                    <option selected value="السعودية">السعوديـــــــة</option>
                  <?php else: ?>
                    <option  value="السعودية">السعوديـــــــة</option>
                  <?php endif; ?>
                  <?php if(old('country')=="قطر"): ?>
                    <option selected value="قطر">قــــطــــــر</option>
                  <?php else: ?>
                    <option  value="قطر">قــــطــــــر</option>
                  <?php endif; ?>
                </select>
              </div>
              <?php if($errors->any()): ?>
                <?php if($errors->has('country')): ?>
                  <div class="form-group bg-danger text-light pt-2 pb-2 text-center">
                    <?php echo e($errors->first('country')); ?>

                  </div>
                <?php endif; ?>
              <?php endif; ?>
              <div class="form-group">
                <label for="exampleInputPass">كــلــمــة المــرور <span>*</span></label>
                <input type="password" name="password" class="form-control" id="exampleInputPass" placeholder="أدخل كلمة المرور" aria-describedby="emailHelp">
              </div>
              <?php if($errors->any()): ?>
                <?php if($errors->has('password')): ?>
                  <div class="form-group bg-danger text-light pt-2 pb-2 text-center">
                    <?php echo e($errors->first('password')); ?>

                  </div>
                <?php endif; ?>
              <?php endif; ?>
              <div class="form-group">
                <label for="exampleInputPass">تـــأكيـــد كــلــمــة المــرور<span>*</span></label>
                <input type="password" name="password_confirmation" class="form-control" id="exampleInputPass" placeholder="تأكيد كـلمة المرور" aria-describedby="emailHelp">
              </div>
              <button type="submit" class="btn badge-pill w-100">
                تسجيل جديد
              </button>
            </form>
          </div>
        </div>
      </div>
</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/toponest/public_html/resources/views/auth/register.blade.php ENDPATH**/ ?>