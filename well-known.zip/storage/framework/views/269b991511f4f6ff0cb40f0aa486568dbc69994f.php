<?php $__env->startPush('css'); ?>
    <style>
        input{
            background-color:#2A3038 !important
        }   
        textarea , select{
          background-color:#2A3038 !important
        } 
    </style>
<?php $__env->stopPush(); ?>


 
  
<?php 
  $title = 'توب وان - لوحة التحكم - عرض بيانات عميل جديد';
?> 

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper ">
            <div class="page-header">
              <h3 class="page-title">جدول العملاء المضافة من قبل المشرفين / عرض بيانات العميل : <?php echo e($row->name); ?></h3>
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="<?php echo e(route('admin.client.index')); ?>" class="btn btn-success pt-2 pl-3 pb-2"> <i class="mdi mdi-arrow-left  d-md-block"></i> </a></li>
                </ol>
              </nav>
            </div>
            <div class="row">
              <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    
                    <form class="forms-sample" >
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>
                        <?php echo $__env->make('admin.client.form_g', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        
                        <?php if(Auth::user()->role == 1): ?>
                        <div class="form-group row">
                            
                            <label for="supervisor" class="col-sm-2 col-form-label">مضاف من قبل</label>
                            <div class="col-sm-10">
                              <input type="text" name="supervisor" class="form-control cairo" id="supervisor" placeholder="مضاف من قبل" value="<?php echo e($supervisor); ?>">
                                
                              
                            </div>
                        
                        
                        </div>
                        <?php endif; ?>
                        
                      
                      <div class="form-group row">
                        <label for="comment" class="col-sm-2 col-form-label">التعليق</label>
                        <div class="col-sm-10">
                          <textarea name="comment" rows="5" class="form-control cairo" id="comment"  disabled  ><?php echo e($row->comment); ?></textarea>
                            
                          
                        </div>
                       
                        
                      </div>
                     
                        
                      
                        
                  </div>
                </div>
              </div>
              
            </div>
          </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script>
    document.getElementById("name").disabled = true;
    document.getElementById("phone").disabled = true;
    document.getElementById("supervisor").disabled = true;
    document.getElementById("comment").disabled = true;
    
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/toponest/public_html/resources/views/admin/client/show.blade.php ENDPATH**/ ?>