                      <div class="form-group row">
                        <label for="name" class="col-sm-2 col-form-label">اسم المستخدم</label>
                        <div class="col-sm-4">
                          <input type="text" name="name" class="form-control cairo" id="name" placeholder=" اسم المستخدم" value="<?php echo e(isset($row)? $row->name : old('name')); ?>" >
                            
                          
                        </div>
                        <label for="email" class="col-sm-2 col-form-label">البريد الالكتروني</label>
                        <div class="col-sm-4">
                          <input type="email" name="email" id="email" class="form-control cairo" placeholder=" البريد الالكتروني" value="<?php echo e(isset($row)? $row->email : old('email')); ?>" >
                        </div>
                        
                      </div>
                      <?php if($errors->any()): ?>
                        <div class=" row">
                            
                                <div class="col-sm-2"></div>
                                <div class="col-sm-4  text-center" >
                                  <?php if($errors->has('name')): ?>
                                    <p class="pt-2 pb-2  bg-danger" style="border-radius:50px !important"><?php echo e($errors->first('name')); ?></p>
                                  <?php endif; ?>
                                </div>
                            
                                <div class="col-sm-2"></div>
                                  <div class="col-sm-4  text-center" >
                                    <?php if($errors->has('email') ): ?>
                                      <p class="pt-2 pb-2  bg-danger" style="border-radius:50px !important"><?php echo e($errors->first('email')); ?></p>
                                    <?php endif; ?>
                                  </div>
                                
                            
                        </div>
                      <?php endif; ?>
                      <div class="form-group row">
                        <label for="phone" class="col-sm-2 col-form-label">رقم الهاتف</label>
                        <div class="col-sm-4">
                          <input type="text" id="phone" name="phone" class="form-control cairo" id="phone" placeholder=" رقم الهاتف" value="<?php echo e(isset($row)? $row->phone : old('phone')); ?>" >
                            
                          
                        </div>
                        <label for="email" class="col-sm-2 col-form-label">الدولة</label>
                        <div class="col-sm-4">
                          <select class="form-control cairo" name="country" id="country">
                            <option disabled selected>إختر الدولة</option>
                            <?php if(old('country')=="مصر" ): ?>                              
                                <option selected value="مصر">مـــــــصـــــر</option>
                            <?php elseif(isset($row)): ?>
                              <?php if($row->country == 'مصر'): ?>
                                  <option selected value="مصر">مـــــــصـــــر</option>
                              <?php else: ?>
                                <option value="مصر">مـــــــصـــــر</option>
                              <?php endif; ?>
                            <?php else: ?> 
                              
                              <option  value="مصر">مـــــــصـــــر</option>
                            <?php endif; ?>
                            <?php if(old('country')=="السعودية" ): ?>
                                <option selected value="السعودية">السعوديـــــــة</option>
                              
                            <?php elseif( isset($row)): ?>
                              <?php if($row->country == 'السعودية'): ?>
                                <option selected value="السعودية">السعوديـــــــة</option>
                              <?php else: ?>
                                <option  value="السعودية">السعوديـــــــة</option>
                              <?php endif; ?> 
                            <?php else: ?>
                              
                              <option  value="السعودية">السعوديـــــــة</option>
                            <?php endif; ?>
                            <?php if(old('country')=="قطر" ): ?>
                              
                                  <option selected value="قطر">قــــطــــــر</option>
                            <?php elseif( isset($row)): ?>
                              <?php if($row->country == 'قطر'): ?>
                                  <option selected value="قطر">قــــطــــــر</option>
                              <?php else: ?>
                                  <option  value="قطر">قــــطــــــر</option>
                              <?php endif; ?>
                              
                             
                            <?php else: ?>
                              
                              <option  value="قطر">قــــطــــــر</option>
                            <?php endif; ?>
                          </select>
                        </div>
                        
                      </div>
                      <?php if($errors->any()): ?>
                        <div class=" row">
                            
                                <div class="col-sm-2"></div>
                                <div class="col-sm-4  text-center" >
                                  <?php if($errors->has('phone')): ?>
                                    <p class="pt-2 pb-2  bg-danger" style="border-radius:50px !important"><?php echo e($errors->first('phone')); ?></p>
                                  <?php endif; ?>
                                </div>
                            
                                <div class="col-sm-2"></div>
                                  <div class="col-sm-4  text-center" >
                                    <?php if($errors->has('country') ): ?>
                                      <p class="pt-2 pb-2  bg-danger" style="border-radius:50px !important"><?php echo e($errors->first('country')); ?></p>
                                    <?php endif; ?>
                                  </div>
                                
                            
                        </div>
                      <?php endif; ?>
                        
                      
                      
                      
                     
                      
                      
                      
                      
                     
                      
                      
                      
                      
                     
                      
                      <?php /**PATH /home/goldenss/public_html/resources/views/admin/client/form.blade.php ENDPATH**/ ?>