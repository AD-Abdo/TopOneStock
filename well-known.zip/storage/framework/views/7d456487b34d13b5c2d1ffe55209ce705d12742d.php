<?php $__env->startPush('css'); ?>
    <style>
        input{
            background-color:#2A3038 !important
        }    
    </style>
<?php $__env->stopPush(); ?>


 
  
<?php 
  $title = 'توب وان - لوحة التحكم - تعديل بيانات عميل';
?> 

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper ">
            <div class="page-header">
              <h3 class="page-title">جدول العملاء المضافة من قبل المشرفين / تعديل بيانات العميل : <?php echo e($row->name); ?></h3>
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="<?php echo e(route('admin.client.index')); ?>" class="btn btn-success pt-2 pl-3 pb-2"> <i class="mdi mdi-arrow-left  d-md-block"></i> </a></li>
                </ol>
              </nav>
            </div>
            <div class="row">
              <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    
                    <form class="forms-sample" action="<?php echo e(route('admin.client.update',$row->id)); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>
                        <?php echo $__env->make('admin.client.form_g', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        
                      
                      <div class="form-group row">
                        <label for="comment" class="col-sm-2 col-form-label">التعليق</label>
                        <div class="col-sm-10">
                          <textarea name="comment" rows="5" class="form-control cairo" id="comment"   ><?php echo e($row->comment); ?></textarea>
                            
                          
                        </div>
                       
                        
                      </div>
                      <?php if($errors->any()): ?>
                        <div class=" row">
                            
                                
                                <div class="col-sm-2"></div>
                                  <div class="col-sm-10  text-center" >
                                    <?php if($errors->has('comment') ): ?>
                                      <p class="pt-2 pb-2  bg-danger" style="border-radius:50px !important"><?php echo e($errors->first('comment')); ?></p>
                                    <?php endif; ?>
                                  </div>
                                
                            
                        </div>
                      <?php endif; ?>

                        
                      
                        <div class=" row  w-100 mt-4">
                            <div class="col-md-4">
                            </div>
                            <div class="col-md-4">

                                <input type="submit" class="text-center btn btn-primary w-100 cairo" value="تعديل">
                            </div>
                            <div class="col-md-4">
                            </div>

                        </div>
                    </form>
                  </div>
                </div>
              </div>
              
            </div>
          </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script>
    document.getElementById("email").disabled = true;
    
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/toponest/public_html/resources/views/admin/client/edit.blade.php ENDPATH**/ ?>