<?php $__env->startPush('css'); ?>
    <style>
        input{
            background-color:#2A3038 !important
        }    
    </style>
<?php $__env->stopPush(); ?>

 
  
<?php 
  $title = 'جولدن - لوحة التحكم - عرض سهم ';
?> 

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper ">
            <div class="page-header">
              <h3 class="page-title">جدول الاسهم / عرض بيانات سهم : <span style="text-decoration: underline"><?php echo e($row->name); ?></span></h3>
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="<?php echo e(route('admin.share.index')); ?>" class="btn btn-success pt-2 pl-3 pb-2"> <i class="mdi mdi-arrow-left  d-md-block"></i> </a></li>
                </ol>
              </nav>
            </div>
            <div class="row">
              <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    
                    <form class="forms-sample">

                        <?php echo $__env->make('admin.share.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


                    </form>
                  </div>
                </div>
              </div>
              
            </div>
          </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script>
    document.getElementById("code").disabled = true;
    document.getElementById("name").disabled = true;
    document.getElementById("buy_date").disabled = true;
    document.getElementById("buy_time").disabled = true;
    document.getElementById("sell_date").disabled = true;
    document.getElementById("sell_time").disabled = true;
    document.getElementById("buy_salary").disabled = true;
    document.getElementById("sell_salary").disabled = true;
    document.getElementById("no_cookies").disabled = true;

</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Mohamed\im\GoldenSSM\resources\views/admin/share/show.blade.php ENDPATH**/ ?>