<?php $__env->startPush('css'); ?>
    <style>
        input{
            background-color:#2A3038 !important
        }    
    </style>
<?php $__env->stopPush(); ?>

 
  
<?php 
  $title = 'توب وان - لوحة التحكم - عرض المشرفين ';
?> 

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper ">
            <div class="page-header">
              <h3 class="page-title">جدول المشرفين / عرض المشرف : <?php echo e($row->name); ?></h3>
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="<?php echo e(route('admin.user.index')); ?>" class="btn btn-success pt-2 pl-3 pb-2"> <i class="mdi mdi-arrow-left  d-md-block"></i> </a></li>
                </ol>
              </nav>
            </div>
            <div class="row">
              <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    
                    <form class="forms-sample" >
                        
                        <?php echo $__env->make('admin.user.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <div class="form-group row">
                        
                        <label for="image" class="col-sm-2 col-form-label">الرتبة</label>
                        <div class="col-sm-10">
                          <?php 
                            $role = "";
                              if($row->role == 1){$role="مدير";}
                                    
                            elseif($row->role == 2){$role="مشرف";}
                                    
                            else{$role="مستخدم عادي";}
                                    
                          ?>
                          <input type="text"  name="role" disabled  class="form-control cairo" id="role" placeholder="الرتبة" value="<?php echo e($role); ?>">
                        </div>
                      </div>
                        <?php if($row->image != null): ?>

                    <div class="form-group row">
                        
                        <label for="image" class="col-sm-2 col-form-label">الصورة</label>
                        <div class="col-sm-10">
                          <img class="img-lg rounded-circle mb-3" src="/user/<?php echo e($row->image); ?>">
                        </div>
                      </div>
                      
                      
                    <?php endif; ?>
                      <?php if($errors->any()): ?>
                        <div class=" row">
                            
                                
                              
                            
                                <div class="col-sm-2"></div>
                                <div class="col-sm-10  text-center" >
                                  <?php if($errors->has('image') ): ?>
                                    <p class="pt-2 pb-2  bg-danger" style="border-radius:50px !important"><?php echo e($errors->first('image')); ?></p>
                                  <?php endif; ?>
                                </div>
                            
                        </div>
                      <?php endif; ?>
                      
                        
                    </form>
                  </div>
                </div>
              </div>
              
            </div>
          </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script>
    document.getElementById("name").disabled = true;
    document.getElementById("email").disabled = true;
    document.getElementById("password").disabled = true;
    document.getElementById("password_confirmed").disabled = true;
    

</script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/toponest/public_html/resources/views/admin/user/show.blade.php ENDPATH**/ ?>