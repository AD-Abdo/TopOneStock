<?php $__env->startPush('css'); ?>
    <style>
        input{
            background-color:#2A3038 !important
        }   
        textarea , select{
          background-color:#2A3038 !important;
          color: #fff;
        } 
    </style>
<?php $__env->stopPush(); ?>


 
  
<?php 
  $title = 'جولدن - لوحة التحكم - عرض بيانات عميل جديد';
?> 

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper ">
            <div class="page-header">
              <h3 class="page-title">جدول العملاء / عرض بيانات العميل : <?php echo e($row->name); ?></h3>
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="<?php echo e(route('admin.customer')); ?>" class="btn btn-success pt-2 pl-3 pb-2"> <i class="mdi mdi-arrow-left  d-md-block"></i> </a></li>
                </ol>
              </nav>
            </div>
            <div class="row">
              <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    
                    <form class="forms-sample" >
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('POST'); ?>
                                              <div class="form-group row">
                        <label for="name" class="col-sm-2 col-form-label">اسم المستخدم</label>
                        <div class="col-sm-4">
                          <input type="text" name="name" class="form-control cairo" id="name" placeholder=" اسم المستخدم" value="<?php echo e(isset($row)? $row->name : old('name')); ?>" >
                            
                          
                        </div>
                        <label for="email" class="col-sm-2 col-form-label">البريد الالكتروني</label>
                        <div class="col-sm-4">
                          <input type="email" name="email" id="email" class="form-control cairo" placeholder=" البريد الالكتروني" value="<?php echo e(isset($row)? $row->email : old('email')); ?>" >
                        </div>
                        
                      </div>
                      <?php if($errors->any()): ?>
                        <div class=" row">
                            
                                <div class="col-sm-2"></div>
                                <div class="col-sm-4  text-center" >
                                  <?php if($errors->has('name')): ?>
                                    <p class="pt-2 pb-2  bg-danger" style="border-radius:50px !important"><?php echo e($errors->first('name')); ?></p>
                                  <?php endif; ?>
                                </div>
                            
                                <div class="col-sm-2"></div>
                                  <div class="col-sm-4  text-center" >
                                    <?php if($errors->has('email') ): ?>
                                      <p class="pt-2 pb-2  bg-danger" style="border-radius:50px !important"><?php echo e($errors->first('email')); ?></p>
                                    <?php endif; ?>
                                  </div>
                                
                            
                        </div>
                      <?php endif; ?>
                      <div class="form-group row">
                        <label for="phone" class="col-sm-2 col-form-label">رقم الهاتف</label>
                        <div class="col-sm-4">
                          <input type="text" id="phone" name="phone" class="form-control cairo" id="phone" placeholder=" رقم الهاتف" value="<?php echo e(isset($row)? $row->phone : old('phone')); ?>" >
                            
                          
                        </div>
                        <label for="email" class="col-sm-2 col-form-label">الدولة</label>
                        <div class="col-sm-4">
                          <select class="form-control cairo" name="country" id="country">
                            <option disabled selected>إختر الدولة</option>
                            <?php if(old('country')=="مصر" ): ?>                              
                                <option selected value="مصر">مـــــــصـــــر</option>
                            <?php elseif(isset($row)): ?>
                              <?php if($row->country == 'مصر'): ?>
                                  <option selected value="مصر">مـــــــصـــــر</option>
                              <?php else: ?>
                                <option value="مصر">مـــــــصـــــر</option>
                              <?php endif; ?>
                            <?php else: ?> 
                              
                              <option  value="مصر">مـــــــصـــــر</option>
                            <?php endif; ?>
                            <?php if(old('country')=="السعودية" ): ?>
                                <option selected value="السعودية">السعوديـــــــة</option>
                              
                            <?php elseif( isset($row)): ?>
                              <?php if($row->country == 'السعودية'): ?>
                                <option selected value="السعودية">السعوديـــــــة</option>
                              <?php else: ?>
                                <option  value="السعودية">السعوديـــــــة</option>
                              <?php endif; ?> 
                            <?php else: ?>
                              
                              <option  value="السعودية">السعوديـــــــة</option>
                            <?php endif; ?>
                            <?php if(old('country')=="قطر" ): ?>
                              
                                  <option selected value="قطر">قــــطــــــر</option>
                            <?php elseif( isset($row)): ?>
                              <?php if($row->country == 'قطر'): ?>
                                  <option selected value="قطر">قــــطــــــر</option>
                              <?php else: ?>
                                  <option  value="قطر">قــــطــــــر</option>
                              <?php endif; ?>
                              
                             
                            <?php else: ?>
                              
                              <option  value="قطر">قــــطــــــر</option>
                            <?php endif; ?>
                          </select>
                        </div>
                        
                      </div>
                      <?php if($errors->any()): ?>
                        <div class=" row">
                            
                                <div class="col-sm-2"></div>
                                <div class="col-sm-4  text-center" >
                                  <?php if($errors->has('phone')): ?>
                                    <p class="pt-2 pb-2  bg-danger" style="border-radius:50px !important"><?php echo e($errors->first('phone')); ?></p>
                                  <?php endif; ?>
                                </div>
                            
                                <div class="col-sm-2"></div>
                                  <div class="col-sm-4  text-center" >
                                    <?php if($errors->has('country') ): ?>
                                      <p class="pt-2 pb-2  bg-danger" style="border-radius:50px !important"><?php echo e($errors->first('country')); ?></p>
                                    <?php endif; ?>
                                  </div>
                                
                            
                        </div>
                      <?php endif; ?>
                        
                        <?php if($row->agree_date != null): ?>
                          <div class="form-group row">
                            <label for="status" class="col-sm-2 col-form-label">الحالة</label>
                            <div class="col-sm-4">
                              <input type="text" name="status" class="form-control cairo" disabled id="status" placeholder="حالة العميل" value="<?php echo e($row->status == 1 ? 'مفعل' : 'غير مفعل'); ?>">
                                
                              
                            </div>
                            <label for="agree_date" class="col-sm-2 col-form-label">تاريخ التفعيل</label>
                            <div class="col-sm-4">
                              <input type="text" name="agree_date" class="form-control cairo" disabled id="agree_date" placeholder="تاريخ التفعيل" value="<?php echo e($row->agree_date); ?>">
                                
                              
                            </div>
                        
                        
                          </div>
                        <?php else: ?>
                          <div class="form-group row">
                            <label for="status" class="col-sm-2 col-form-label">الحالة</label>
                            <div class="col-sm-10">
                              <input type="text" name="status" class="form-control cairo" id="status" disabled placeholder="حالة العميل" value="<?php echo e($row->status == 1 ? 'مفعل' : 'غير مفعل'); ?>">
                                
                              
                            </div>
                            
                        
                        
                          </div>
                        <?php endif; ?>
                        
                        
                      
                      <div class="form-group row">
                        <label for="comment" class="col-sm-2 col-form-label">التعليق</label>
                        <div class="col-sm-10">
                          <textarea name="comment" rows="5" class="form-control cairo" id="comment"  disabled ><?php echo e($row->comment); ?></textarea>
                            
                          
                        </div>
                       
                        
                      </div>
                     
                        
                      
                        
                  </div>
                </div>
              </div>
              
            </div>
          </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
<script>
    document.getElementById("name").disabled = true;
    document.getElementById("email").disabled = true;
    document.getElementById("country").disabled = true;
    document.getElementById("phone").disabled = true;
    document.getElementById("supervisor").disabled = true;
    document.getElementById("comment").disabled = true;
    document.getElementById("status").disabled = true;
    document.getElementById("agree_date").disabled = true;
    
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/goldenss/public_html/resources/views/admin/user/customer_show.blade.php ENDPATH**/ ?>