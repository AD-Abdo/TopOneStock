                      <div class="form-group row">
                        <label for="name" class="col-sm-2 col-form-label">اسم المستخدم</label>
                        <div class="col-sm-10">
                          <input type="text" name="name" class="form-control cairo" id="name" placeholder=" اسم المستخدم" value="<?php echo e(isset($row)? $row->name : old('name')); ?>" >
                            
                          
                        </div>
                        
                        
                      </div>
                      <?php if($errors->any()): ?>
                        <div class=" row">
                            
                                <div class="col-sm-2"></div>
                                <div class="col-sm-10  text-center" >
                                  <?php if($errors->has('name')): ?>
                                    <p class="pt-2 pb-2  bg-danger" style="border-radius:50px !important"><?php echo e($errors->first('name')); ?></p>
                                  <?php endif; ?>
                                </div>
                            
                               
                            
                        </div>
                      <?php endif; ?>
                      <div class="form-group row">
                        <label for="phone" class="col-sm-2 col-form-label">رقم الهاتف</label>
                        <div class="col-sm-10">
                          <input type="text" id="phone" name="phone" class="form-control cairo" id="phone" placeholder=" رقم الهاتف" value="<?php echo e(isset($row)? $row->phone : old('phone')); ?>" >
                            
                          
                        </div>
                        
                        
                      </div>
                      <?php if($errors->any()): ?>
                        <div class=" row">
                            
                                <div class="col-sm-2"></div>
                                <div class="col-sm-10  text-center" >
                                  <?php if($errors->has('phone')): ?>
                                    <p class="pt-2 pb-2  bg-danger" style="border-radius:50px !important"><?php echo e($errors->first('phone')); ?></p>
                                  <?php endif; ?>
                                </div>
                            
                               
                                
                            
                        </div>
                      <?php endif; ?>
                        
                      
                      
                      
                     
                      
                      
                      
                      
                     
                      
                      
                      
                      
                     
                      
                      <?php /**PATH /home/toponest/public_html/resources/views/admin/client/form_g.blade.php ENDPATH**/ ?>