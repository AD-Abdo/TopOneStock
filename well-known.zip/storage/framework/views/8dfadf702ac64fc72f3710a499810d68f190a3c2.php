 
  
<?php 
  $title = 'جولدن - لوحة التحكم - جدول اشتراكات الباقات';
?> 

<?php $__env->startSection('content'); ?>

    <div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title">اشتراكات الباقات </h3>
              
            </div>
            <div class="row">
              <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    
                    <div class="table-responsive">
                      <table class="table">
                        
                        <thead>
                           <tr>
                            <form method="POST" action="<?php echo e(route('admin.participation.filter')); ?>">
                              <?php echo csrf_field(); ?>
                              <?php echo method_field('post'); ?>
                              
                              
                              <td colspan="6">
                                <select class="form-control" name="confirm">
                                  <option selected disabled>اختر الحالة</option>
                                  <?php if(isset($confirm)): ?>
                                    <?php if($confirm == 1): ?>
                                      <option selected value="1">الاشتراكات المفعلة</option>
                                    <?php else: ?>
                                      <option value="1">الاشتراكات المفعلة</option>
                                    <?php endif; ?>
                                    <?php if($confirm == 0): ?>
                                      <option value="0" selected> الاشتراكات الغير المفعلة </option>
                                    <?php else: ?>
                                      <option value="0">الاشتراكات الغير المفعلة</option>
                                    <?php endif; ?>
                                  <?php else: ?>
                                    <option value="1">الاشتراكات المفعلة</option>
                                    <option value="0">الاشتراكات الغير المفعلة</option>
                                  <?php endif; ?>
                                </select>
                              </td>
                              
                              <td colspan="1"><input type="submit" class="btn btn-success w-100" value="بحث"></td>
                              <td colspan="1"><a href="<?php echo e(route('admin.participation.index')); ?>" class="btn btn-danger " >X</a></td>

                            </form>

                          </tr>
                          <tr>
                              <td colspan="8"></td>
                              

                          </tr>
                          <tr>
                            <th>الاسم العميل</th>
                            <th>البريد الالكتروني</th>
                            <th>اسم الباقة</th>
                            <th>سعر الباقة</th>
                            <th>التاريخ</th>
                            <th>الوقت</th>
                            <th class="text-center">الحالة</th>
                            <th class="text-center">العمليات</th>
                          </tr>
                        </thead>
                        <tbody>
                            <?php if(count($rows) > 0): ?>
                            <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                <td><?php echo e($row->User->name); ?></td>
                                <td><?php echo e($row->User->email); ?>	</td>
                                <td><?php echo e($row->Package->name); ?></td>
                                <td>
                                  <?php if($row->Package->salary == 0): ?>
                                      مجانية
                                    <?php else: ?>
                                    <?php echo e($row->Package->salary); ?> ريال
                                    <?php endif; ?>
                                </td>
                                
                                <?php
                                  $datetime = explode(' ',$row->created_at);
                                  $date = $datetime[0];
                                  $time = $datetime[1];
                                ?>
                                <td><?php echo e($date); ?></td>
                                <td><?php echo e($time); ?></td>
                                
                                
                                <td class="text-center">
                                  <form action="<?php echo e(route('admin.participation.update', $row->id )); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <?php if($row->confirm == 1): ?>
                                      <button type="submit" class="btn btn-success w-100">تفعيل</i></button>
                                    <?php else: ?>
                                      <button type="submit" class="btn btn-danger w-100">الغاء التفعيل</i></button>
                                    <?php endif; ?>
                                  </form>
                                </td>
                                <td>
                                  <form action="<?php echo e(route('admin.participation.destroy',$row->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>

                                    <button type="submit" class="btn btn-danger"><i class="mdi mdi-delete d-md-block pl-1"></i></button>
                                  </form>
                                
                                </td>
                              </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php else: ?>
                              <tr>
                                <td colspan="8" class="text-center">لا يوجد أى أشتراكات للعملاء</td>
                              </tr>
                          <?php endif; ?>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
             <?php echo e($rows->links()); ?>

            </div>
          </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Mohamed\im\GoldenSSM\resources\views/admin/participation/index.blade.php ENDPATH**/ ?>