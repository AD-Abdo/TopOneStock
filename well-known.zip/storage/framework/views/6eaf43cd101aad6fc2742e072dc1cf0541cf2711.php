<?php 
//active item
    $title = 'تعديل كلمة المرور';
    $item[0] = '';
    $item[1] = '';
    $item[2] = '';
    $item[3] = '';
    $item[4] = '';


?>
<?php $__env->startSection('content'); ?>

<main class="tasgel-gaded">
      <?php if(Session::has('error')): ?>
        <div class="bg bg-danger" id="message">
          <p class="text-light text-center pt-2 pb-2"> <?php echo e(Session::get('error')); ?></p>
        </div>
      <?php endif; ?>
      <?php if(Session::has('message')): ?>
        <div class="bg bg-success" id="message">
          <p class="text-light text-center pt-2 pb-2"> <?php echo e(Session::get('message')); ?></p>
        </div>
      <?php endif; ?>
      <h1 class="text-center animate__ animate__bounceInDown animated" style="visibility: visible; animation-name: bounceInDown;">تعديل كلمة المرور</h1>
      <div class="container">
        <div class="form-content">
          <div class="theForm">
            
            <form method="POST" action="<?php echo e(route('user.profile.password.update')); ?>" >
              <?php echo csrf_field(); ?>
              <?php echo method_field('PUT'); ?>
              <div class="form-group">
                <label for="exampleInputName">كلمة المرور <span>*</span></label>
                <input name="password" type="password" class="form-control" id="exampleInputName" placeholder="أدخل كلمة المرور" aria-describedby="nameHelp">
              </div>
              <?php if($errors->any()): ?>
                <?php if($errors->has('password')): ?>
                  <div class="form-group bg-danger text-light pt-2 pb-2 text-center">
                    <?php echo e($errors->first('password')); ?>

                  </div>
                <?php endif; ?>
              <?php endif; ?>
              
              <div class="form-group">
                <label for="exampleInputPhone">تاكيد كلمة المرور <span>*</span></label>
                <input type="password"  name="password_confirmation" class="form-control" id="exampleInputPhone" placeholder="أدخل تاكيد كلمة المرور" aria-describedby="emailHelp">
              </div>
              
              
              
              <button type="submit" class="btn badge-pill w-100">
                تعديل
              </button>
            </form>
          </div>
        </div>
      </div>
</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Mohamed\im\GoldenSSM\resources\views/auth/password.blade.php ENDPATH**/ ?>