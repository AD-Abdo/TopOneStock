<?php 
//active item
    $title = 'الصفحة الشخصية';
    $item[0] = '';
    $item[1] = '';
    $item[2] = '';
    $item[3] = '';
    $item[4] = '';


?>
<?php $__env->startSection('content'); ?>

<main class="profile">
      <?php if(Session::has('message')): ?>
        <div class="bg bg-success" id="message">
          <p class="text-light text-center pt-2 pb-2"> <?php echo e(Session::get('message')); ?></p>
        </div>
      <?php endif; ?>
      <h1 class="text-center animate__ animate__bounceInUp animated" style="visibility: visible; animation-name: bounceInUp;">الصفحة الشخصية</h1>
      <div class="container">
        <div class="profile-content">
         <div class="img animate__ animate__bounceInRight animated" style="visibility: visible; animation-name: bounceInRight;">
            <?php if(Auth::user()->image != null): ?>
              <img src="/user/<?php echo e(Auth::user()->image); ?>" alt="صورة العميل <?php echo e(Auth::user()->name); ?>">
            <?php else: ?>
              <img src="/web/imgs/images (1).jpeg" alt="صورة العميل <?php echo e(Auth::user()->name); ?>">
            <?php endif; ?>
            
          </div>
          <div class="text">
            <ul class="list-unstyled lead">
              <li><span>الاسم</span> : <?php echo e(Auth::user()->name); ?></li>
              <li><span>البريد الالكتروني</span> : <?php echo e(Auth::user()->email); ?></li>
              <li><span>البلد</span> : <?php echo e(Auth::user()->country); ?></li>
              <li><span>رقم الهاتف</span> : <?php echo e(Auth::user()->phone); ?></li>
              <li class="text-center"><a href="<?php echo e(route('user.profile.edit')); ?>" class="btn btn-success w-100">تعديل</a></li>
            </ul>
          </div>
        </div>
      </div>
    </main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Mohamed\im\GoldenSSM\resources\views/auth/profile.blade.php ENDPATH**/ ?>