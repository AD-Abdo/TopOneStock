 
  
<?php 
  $title = 'جولدن - لوحة التحكم - جدول الاسهم';
?> 

<?php $__env->startSection('content'); ?>

    <div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title">جدول الاسهم </h3>
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="<?php echo e(route('admin.share.create')); ?>" class="btn btn-success pt-2 pl-3 pb-2"> <i class="mdi mdi-plus  d-md-block"></i> </a></li>
                </ol>
              </nav>
            </div>
            <div class="row">
              <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    
                    <div class="table-responsive">
                      <table class="table">
                        <thead>
                          <tr>
                            <th>الكود</th>
                            <th>الاسم</th>
                            <th>سعر الشراء</th>
                            <th>سعر البيع</th>
                            <th>عدد الجلسات</th>
                            <th>الحالة</th>
                            <th>نسبة الربح</th>
                            <th colspan="3" class="text-center">العمليات</th>
                          </tr>
                        </thead>
                        <tbody>
                          <?php if(count($rows) > 0): ?>
                            <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                <td><?php echo e($row->code); ?></td>
                                <td><?php echo e($row->name); ?>	</td>
                                <td><?php echo e($row->buy_salary); ?></td>
                                <td><?php echo e($row->sell_salary); ?></td>
                                <td><?php echo e($row->no_cookies); ?></td>
                                <?php if($row->status == 1): ?>
                                <td><label class="badge badge-success">
                                  <i class="mdi mdi-arrow-top-right d-md-block pl-1"></i>  
                                </label></td>
                                <?php else: ?>
                                <td><label class="badge badge-danger">
                                  <i class="mdi mdi-arrow-bottom-left d-md-block pl-1"></i>  
                                </label></td>
                                <?php endif; ?>
                                <td><?php echo e($row->profit); ?></td>
                                <td><a href="<?php echo e(route('admin.share.show',$row->id)); ?>" class="btn btn-info"><i class="mdi mdi-eye  d-md-block pl-1"></i></a></td>
                                <td><a href="<?php echo e(route('admin.share.edit',$row->id)); ?>" class="btn btn-primary"><i class="mdi mdi-pencil  d-md-block pl-1"></i></a></td>
                                <td>
                                  <form action="<?php echo e(route('admin.share.destroy',$row->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>

                                    <button type="submit" class="btn btn-danger"><i class="mdi mdi-delete d-md-block pl-1"></i></button>
                                  </form>
                                
                                </td>
                              </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php else: ?>
                              <tr>
                                <td colspan="10" class="text-center">لا يوجد أى أسهم مضافة مسبقا</td>
                              </tr>
                          <?php endif; ?>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
              <?php echo e($rows->links()); ?>

            </div>
          </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\GoldenSSM\resources\views/admin/share/index.blade.php ENDPATH**/ ?>