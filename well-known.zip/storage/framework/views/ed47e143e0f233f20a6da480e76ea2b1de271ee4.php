<?php $__env->startPush('css'); ?>
    <style>
        input{
            background-color:#2A3038 !important
        }    
    </style>
<?php $__env->stopPush(); ?>

 
  
<?php 
  $title = 'جولدن - لوحة التحكم - تغيير كلمة المرور ';
?> 

<?php $__env->startSection('content'); ?>
    <div class="content-wrapper ">
            <div class="page-header">
              <h3 class="page-title">تغيير كلمة المرور </h3>
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="<?php echo e(route('admin.home')); ?>" class="btn btn-success pt-2 pl-3 pb-2"> <i class="mdi mdi-arrow-left  d-md-block"></i> </a></li>
                </ol>
              </nav>
            </div>
            <div class="row">
              <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">

                    
                    
                    <form class="forms-sample" enctype="multipart/form-data" method="POST" action="<?php echo e(route('admin.profile.password.update')); ?>">
                      <?php echo csrf_field(); ?>
                      <?php echo method_field('put'); ?>

                        
                    <div class="form-group row">
                        <label for="password" class="col-sm-2 col-form-label">كلمة المرور</label>
                        <div class="col-sm-4">
                          <input type="password" name="password" class="form-control cairo" id="password" placeholder=" كلمة المرور">
                            
                          
                        </div>
                        <label for="confirmPassword" class="col-sm-2 col-form-label">تاكيد كلمة المرور</label>
                        <div class="col-sm-4">
                          <input type="password" name="password_confirmation" id="confirmPassword" class="form-control cairo" id="confirmPassword" placeholder=" تاكيد كلمة المرور" >
                        </div>
                        
                      </div>
                      <?php if($errors->any()): ?>
                        <div class=" row">
                            
                                <div class="col-sm-2"></div>
                                <div class="col-sm-10  text-center" >
                                  <?php if($errors->has('password')): ?>
                                    <p class="pt-2 pb-2  bg-danger" style="border-radius:50px !important"><?php echo e($errors->first('password')); ?></p>
                                  <?php endif; ?>
                                </div>
                            
                                
                                
                            
                        </div>
                      <?php endif; ?>
                      
                      <div class=" row  w-100 mt-4">
                            <div class="col-md-4">
                            </div>
                            <div class="col-md-4">

                                <input type="submit" class="text-center btn btn-primary w-100 cairo" value="تعديل">
                            </div>
                            <div class="col-md-4">
                            </div>

                        </div>
                    </form>
                  </div>
                </div>
              </div>
              
            </div>
          </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
<script>
    document.getElementById("email").disabled = true;
    
</script>
<?php $__env->stopPush(); ?>




<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/goldenss/public_html/resources/views/admin/profile/password.blade.php ENDPATH**/ ?>