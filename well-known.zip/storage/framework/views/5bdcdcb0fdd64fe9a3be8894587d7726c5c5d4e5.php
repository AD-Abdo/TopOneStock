<?php $__env->startPush('css'); ?>
  <style>
      .data{
        font-size: .99rem !important;
      }
  </style>
<?php $__env->stopPush(); ?>


<?php 
//active item
    $title = ' معدل الأداء الخاص بالتوصيات';
    $item[0] = '';
    $item[1] = '';
    $item[2] = '';
    $item[3] = '';
    $item[4] = '';


?>
<?php $__env->startSection('content'); ?>
<main class="mo3dl-eladaa">
      <h1 class="text-center animate__ animate__bounceInUp animated" style="visibility: visible; animation-name: bounceInUp;">مــعـــدل الأداء</h1>
      <div class="container">
        <form action="<?php echo e(route('tawsiat.post', $id )); ?>" method="POST">
          <?php echo csrf_field(); ?>
          <?php echo method_field('POST'); ?>
          <h3 class="text-right">إختر تاريخ البحث</h3>
          <div class="form-row">
            <div class="col-sm">
              <select class="form-control" name="year">
                <option selected="">العام</option>
                <option value="19" <?php if($open_custom_year == '19'): ?> selected <?php endif; ?>>2019</option>
                <option value="20" <?php if($open_custom_year == '20'): ?> selected <?php endif; ?>>2020</option>
                <option value="21" <?php if($open_custom_year == '21'): ?> selected <?php endif; ?>>2021</option>
                <option value="22" <?php if($open_custom_year == '22'): ?> selected <?php endif; ?>>2022</option>
                <option value="23" <?php if($open_custom_year == '23'): ?> selected <?php endif; ?>>2023</option>
                <option value="24" <?php if($open_custom_year == '24'): ?> selected <?php endif; ?>>2024</option>
                <option value="25" <?php if($open_custom_year == '25'): ?> selected <?php endif; ?>>2025</option>
                <option value="26" <?php if($open_custom_year == '26'): ?> selected <?php endif; ?>>2026</option>
                <option value="27" <?php if($open_custom_year == '27'): ?> selected <?php endif; ?>>2027</option>
                <option value="28" <?php if($open_custom_year == '28'): ?> selected <?php endif; ?>>2028</option>
                <option value="29" <?php if($open_custom_year == '29'): ?> selected <?php endif; ?>>2029</option>
                <option value="30" <?php if($open_custom_year == '30'): ?> selected <?php endif; ?>>2030</option>
              </select>
            </div>
            <div class="col-sm">
              <select class="form-control" name="month">
                <option selected="" >إختر الشهر</option>
                <option value="01" <?php if($open_custom_month == '01'): ?> selected <?php endif; ?>>يناير</option>
                <option value="02" <?php if($open_custom_month == '02'): ?> selected <?php endif; ?>>مارس</option>
                <option value="03" <?php if($open_custom_month == '03'): ?> selected <?php endif; ?>>فبراير</option>
                <option value="04" <?php if($open_custom_month == '04'): ?> selected <?php endif; ?>>إبريل</option>
                <option value="05" <?php if($open_custom_month == '05'): ?> selected <?php endif; ?>>مايو</option>
                <option value="06" <?php if($open_custom_month == '06'): ?> selected <?php endif; ?>>يونيو</option>
                <option value="07" <?php if($open_custom_month == '07'): ?> selected <?php endif; ?>>يوليو</option>
                <option value="08" <?php if($open_custom_month == '08'): ?> selected <?php endif; ?>>أغسطس</option>
                <option value="09" <?php if($open_custom_month == '09'): ?> selected <?php endif; ?>>سبتمبر</option>
                <option value="10" <?php if($open_custom_month == '10'): ?> selected <?php endif; ?>>أكتوبر</option>
                <option value="11" <?php if($open_custom_month == '11'): ?> selected <?php endif; ?>>نوفمبر</option>
                <option value="12" <?php if($open_custom_month == '12'): ?> selected <?php endif; ?>>ديسمبر</option>
              </select>
            </div>
            <div class="col-sm">
              <button type="submit" class="btn w-100">
                بـحــث
              </button>
            </div>
          </div>
        </form>
        <div class="twsiat-results">
          <h3 class="text-right">نتائج شهر <?php echo e($month); ?></h3>
          <ul class="list-unstyled">
            <li>إجمالى عدد التوصيات : <span><?php echo e($count); ?></span> توصية</li>
            <li>عدد التوصيات المحققة : <span><?php echo e($success); ?></span> توصية</li>
            <li>عدد التوصيات ايقاف الخسارة : <span><?php echo e($failed); ?></span> توصية</li>
            <li>متوسط ربح التوصية الواحدة : <span><?php echo e($got_success); ?></span> %</li>
            <li>عدد التوصيات المفتوحة : <span><?php echo e($open_share); ?></span> توصية</li>
          </ul>
        </div>
        <table class="text-center">
          <thead>
            <tr>
              <th class="data" scope="col">كود السهم</th>
              <th class="data" scope="col">اسم السهم</th>
              <th class="data" scope="col" colspan="2">تاريخ الشراء</th>
              <th class="data" scope="col">سعر الشراء</th>
              <th class="data" scope="col" colspan="2">تاريخ البيع</th>
              <th class="data" scope="col">سعر البيع</th>
              <th class="data" scope="col">عدد الجلسات</th>
              <th class="data" scope="col">الحالة</th>
              <th class="data" scope="col">نسبة الربح / الخسارة</th>
            </tr>
          </thead>
          <tbody>
            <?php if($count>0): ?>
              <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php
                $share_date_time = explode(' ',$row->buy_date);
                $share_date = $share_date_time[0];
                $compare_date = '20'.date('y-m-d',strtotime($share_date.' + '.($row->no_cookies-1).' days'));
              ?>
              <?php if($share_date >= $open_custom_date && $share_date <= $end_custom_date): ?>
                    
                <?php if($compare_date >= $real_date): ?>
                        
                
                  <?php else: ?>
                    <tr>
                      <td class="data" data-label="كود السهم"><?php echo e($row->code); ?></td>
                      <td class="data" data-label="اسم السهم"><?php echo e($row->name); ?></td>
                      <td class="data"data-label="تاريخ الشراء" colspan="2"><?php echo e($row->buy_date); ?> </td>
                      <td class="data" data-label="سعر الشراء"><?php echo e($row->buy_salary); ?></td>
                      <td class="data" data-label="تاريخ البيع" colspan="2"><?php echo e($row->sell_date); ?></td>
                      <td class="data" data-label="سعر البيع"><?php echo e($row->sell_salary); ?></td>
                      <td class="data" data-label="عدد الجلسات"><?php echo e($row->no_cookies); ?></td>
                      
                      <td class="data" data-label="الحالة">
                        <?php if($row->status == 1): ?>
                          <i class="fas fa-arrow-up" ></i> رابحة
                        <?php else: ?>
                          <i class="fas fa-arrow-down"></i> خسارة
                        <?php endif; ?>
                      </td>
                      <td class="data" data-label="نسبة الربح / الخسارة"><?php echo e($row->profit); ?></td>
                    </tr>

                  <?php endif; ?>
                      
                <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>
              <tr>
                <td colspan="11" class="data">لا يوجد توصيات </td>
              </tr>
            <?php endif; ?>
            
          </tbody>
        </table>
      </div>
    </main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Mohamed\im\GoldenSSM\resources\views/getTawsiat.blade.php ENDPATH**/ ?>