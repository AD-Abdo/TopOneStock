<!-- Start Navbar  -->
    <nav class="navbar navbar-expand-lg navbar-light">
      <div class="container">
        <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
          <img src="/web/imgs/top.png" width="95" height="75" alt="TopOne" />
        </a>
        <button
          class="navbar-toggler"
          type="button"
          data-toggle="collapse"
          data-target="#navbarSupportedContent"
          aria-controls="navbarSupportedContent"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item <?php echo e($item[0]); ?>">
              <a class="nav-link text-uppercase" href="<?php echo e(route('home')); ?>"
                >الرئيسيــــــــة</a
              >
            </li>
            <li class="nav-item <?php echo e($item[1]); ?>">
              <a class="nav-link text-uppercase" href="<?php echo e(route('packages')); ?>"
                >باقات توب وان</a
              >
            </li>
            <li class="nav-item <?php echo e($item[2]); ?>">
              <a class="nav-link text-uppercase" href="<?php echo e(route('tawsiat')); ?>"
                >معدل الأداء</a
              >
            </li>
            <li class="nav-item <?php echo e($item[3]); ?>">
              <a class="nav-link text-uppercase" href="<?php echo e(route('contact')); ?>"
                >تواصل معنا</a
              >
            </li>
            <li class="nav-item <?php echo e($item[4]); ?>">
              <a class="nav-link text-uppercase" href="<?php echo e(route('about')); ?>">من نحن</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <!-- End Navbar  --><?php /**PATH /home/toponest/public_html/resources/views/layouts/navbar.blade.php ENDPATH**/ ?>