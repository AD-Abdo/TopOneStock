<!-- content-wrapper ends -->
        <footer class="footer">
          <div class=" text-center">
            <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">كل الحقوق محفوظة لــ ©  <a
                href="https://www.goldenssm.com" target="_blank">GoldenSSM</a></span>
          </div>
        </footer>
<?php /**PATH C:\Mohamed\im\GoldenSSM\resources\views/admin/layouts/footer.blade.php ENDPATH**/ ?>