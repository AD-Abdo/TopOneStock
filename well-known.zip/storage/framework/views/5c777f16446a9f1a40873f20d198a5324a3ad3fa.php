 
  
<?php 
  $title = 'جولدن - لوحة التحكم - جدول الباقات';
?> 

<?php $__env->startSection('content'); ?>

    <div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title">جدول الباقات </h3>
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="<?php echo e(route('admin.package.create')); ?>" class="btn btn-success pt-2 pl-3 pb-2"> <i class="mdi mdi-plus  d-md-block"></i> </a></li>
                </ol>
              </nav>
            </div>
            <div class="row">
              <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    
                    <div class="table-responsive">
                      <table class="table">
                        
                        <thead>
                           <tr>
                            <form method="POST" action="<?php echo e(route('admin.package.filter.post')); ?>">
                              <?php echo csrf_field(); ?>
                              <?php echo method_field('post'); ?>
                              
                              <td colspan="4"><input type="text" name="name" class="form-control" value="<?php echo e(old('name')); ?>" placeholder="اسم الباقة"></td>
                              
                              <td><input type="submit" class="btn btn-success w-100" value="بحث"></td>
                              <td colspan="1"><a href="<?php echo e(route('admin.package.index')); ?>" class="btn btn-danger " >X</a></td>
                            </form>

                          </tr>
                          <tr>
                              <td colspan="6"></td>
                              

                          </tr>
                          <tr>
                            <th>اسم الباقة</th>
                            <th>وصف الباقة</th>
                            <th>سعر الباقة</th>
                            <th colspan="3" class="text-center">العمليات</th>
                          </tr>
                        </thead>
                        <tbody>
                            <?php if(count($rows) > 0): ?>
                            <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                <td>باقة <?php echo e($row->name); ?></td>
                                <td>
                                  <?php if(Str::length($row->description)<=50): ?>
                                    <?php echo e($row->description); ?>

                                  <?php else: ?>
                                    <?php echo e(Str::limit($row->description,50)); ?> الخ
                                  <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($row->salary == 0): ?>
                                      مجانية
                                    <?php else: ?>
                                    <?php echo e($row->salary); ?> ريال
                                    <?php endif; ?>
                                </td>
                                <td><a href="<?php echo e(route('admin.package.show', $row->id)); ?>" class="btn btn-info"><i class="mdi mdi-eye  d-md-block pl-1"></i></a></td>
                                <td><a href="<?php echo e(route('admin.package.edit', $row->id)); ?>" class="btn btn-primary"><i class="mdi mdi-pencil  d-md-block pl-1"></i></a></td>
                                <td>
                                  <form action="<?php echo e(route('admin.package.destroy',$row->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>

                                    <button type="submit" class="btn btn-danger"><i class="mdi mdi-delete d-md-block pl-1"></i></button>
                                  </form>
                                
                                </td>
                              </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php else: ?>
                              <tr>
                                <td colspan="6" class="text-center">لا يوجد أى باقة</td>
                              </tr>
                          <?php endif; ?>
                        </tbody>
                      </table>
                    </div>
                    
                  </div>
                </div>
              </div>
             <?php echo e($rows->links()); ?>

            </div>
          </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Mohamed\im\GoldenSSM\resources\views/admin/package/index.blade.php ENDPATH**/ ?>