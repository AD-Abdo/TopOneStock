
 
  
<?php 
  $title = 'توب وان - لوحة التحكم - جدول العملاء';
?> 

<?php $__env->startSection('content'); ?>

    <div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title">جدول العملاء المضافة من قبل المشرفين</h3>
              <?php if(Auth::user()->role == 2): ?>
              <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="<?php echo e(route('admin.client.create')); ?>" class="btn btn-success pt-2 pl-3 pb-2"> <i class="mdi mdi-plus  d-md-block"></i> </a></li>
                </ol>
              </nav>
              <?php endif; ?>
            </div>
            <div class="row">
              <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    
                    <div class="table-responsive">
                      <table class="table">
                        
                        <thead>
                          <?php if(Auth::user()->role == 1): ?>
                           <tr>
                            <form method="POST" action="<?php echo e(route('admin.client.filter')); ?>">
                              <?php echo csrf_field(); ?>
                              <?php echo method_field('post'); ?>
                              
                              
                              <td colspan="4">
                                <div class="col-sm-12">
                                  <input type="text" name="name" class="form-control cairo" id="name" placeholder=" البحث باسم المستخدم" value="<?php echo e(isset($row)? $row->name : old('name')); ?>" >
                                      
                                    
                                  
                                  
                                </div>
                              </td>
                              
                              
                              <td colspan="1"><input type="submit" class="btn btn-success w-100" value="بحث"></td>
                              <td colspan="1"><a href="<?php echo e(route('admin.client.index')); ?>" class="btn btn-danger w-100" >X</a></td>
                            </form>

                          </tr>
                          <?php endif; ?>
                          <tr>
                            <?php if(Auth::user()->role == 1): ?>
                              <td colspan="6"></td>
                            <?php elseif(Auth::user()->role == 1): ?>
                              <td colspan="5"></td>
                            <?php endif; ?>
                              

                          </tr>
                          <tr>
                            <th>الاسم</th>
                            <th>رقم الهاتف</th>
                            
                            <?php if(Auth::user()->role == 1): ?>
                              <th>مضاف من قبل</th>
                            <?php endif; ?>
                            <?php if(Auth::user()->role == 1): ?>
                              <th colspan="3" class="text-center">الحالة</th>
                            <?php elseif(Auth::user()->role == 2): ?>
                              <th colspan="1" class="text-center">الحالة</th>
                            <?php endif; ?>
                          </tr>
                        </thead>
                        <tbody>
                          <?php if(Auth::user()->role == 1): ?>
                            <?php if(count($rows) > 0): ?>
                              <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                  <td><?php echo e($row->Customer->name); ?></td>
                                  <td><?php echo e($row->Customer->phone); ?>	</td>
                                  <td><?php echo e($row->Supervisor->name); ?>	</td>
                                  
                                  <td><a href="<?php echo e(route('admin.client.show',$row->id)); ?>" class="btn btn-info"><i class="mdi mdi-eye  d-md-block pl-1"></i></a></td>
                                  <td><a href="<?php echo e(route('admin.client.edit',$row->Customer->id)); ?>" class="btn btn-primary"><i class="mdi mdi-pencil  d-md-block pl-1"></i></a></td>

                                  
                                  
                                  <td class="text-center" colspan="1">
                                    <form action="<?php echo e(route('admin.client.delete', $row->id )); ?>" method="POST">
                                      <?php echo csrf_field(); ?>
                                      <?php echo method_field('POST'); ?>
                                        <button type="submit" class="btn btn-danger"><i class="mdi mdi-delete  d-md-block pl-1"></i></button>
                                    
                                    </form>
                                  </td>
                                  
                                </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <?php if(Auth::user()->role == 1): ?>
                                        <td colspan="6" class="text-center">لا يوجد أى عميل</td>
                                <?php elseif(Auth::user()->role == 2): ?>
                                        <td colspan="5" class="text-center">لا يوجد أى عميل</td>
                                <?php endif; ?>
                            <?php endif; ?>
                          <?php elseif(Auth::user()->role == 2): ?>
                              <?php if(count($rows) > 0): ?>
                                <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <?php if(Auth::user()->id == $row->supervisor_id): ?>
                                  <tr>
                                    <td><?php echo e($row->Customer->name); ?></td>
                                    <td><?php echo e($row->Customer->phone); ?>	</td>
                                    <?php if(Auth::user()->role == 2): ?>
                                    <td class="text-center"><a href="<?php echo e(route('admin.client.show',$row->id)); ?>" class="btn btn-info"><i class="mdi mdi-eye  d-md-block pl-1"></i></a></td>
                                    
                                    <?php elseif(Auth::user()->role == 1): ?>
                                    <td><a href="<?php echo e(route('admin.client.show',$row->id)); ?>" class="btn btn-info"><i class="mdi mdi-eye  d-md-block pl-1"></i></a></td>
                                    <td><a href="<?php echo e(route('admin.client.edit',$row->Customer->id)); ?>" class="btn btn-primary"><i class="mdi mdi-pencil  d-md-block pl-1"></i></a></td>

                                    
                                    
                                    <td class="text-center" colspan="1">
                                      <form action="<?php echo e(route('admin.client.delete', $row->id )); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('POST'); ?>
                                          <button type="submit" class="btn btn-danger w-100">X</i></button>
                                      
                                      </form>
                                    </td>
                                    <?php endif; ?>
                                    
                                  </tr>
                                  
                                  <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              <?php else: ?>
                                  <tr>
                                      <?php if(Auth::user()->role == 1): ?>
                                        <td colspan="6" class="text-center">لا يوجد أى عميل</td>
                                      <?php elseif(Auth::user()->role == 2): ?>
                                        <td colspan="5" class="text-center">لا يوجد أى عميل</td>
                                      <?php endif; ?>
                                  </tr>
                              <?php endif; ?>
                          <?php else: ?>
                            <tr>
                                      <?php if(Auth::user()->role == 1): ?>
                                        <td colspan="6" class="text-center">لا يوجد أى عميل</td>
                                      <?php elseif(Auth::user()->role == 2): ?>
                                        <td colspan="5" class="text-center">لا يوجد أى عميل</td>
                                      <?php endif; ?>
                            </tr>
                          <?php endif; ?>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
             <?php echo e($rows->links()); ?>

            </div>
          </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/toponest/public_html/resources/views/admin/client/index.blade.php ENDPATH**/ ?>