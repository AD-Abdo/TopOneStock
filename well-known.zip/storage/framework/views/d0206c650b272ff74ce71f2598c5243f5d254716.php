
 
  
<?php 
  $title = 'جولدن - لوحة التحكم - جدول العملاء';
?> 

<?php $__env->startSection('content'); ?>

    <div class="content-wrapper">
            <div class="page-header">
              <h3 class="page-title">جدول العملاء </h3>
              
            </div>
            <div class="row">
              <div class="col-lg-12 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    
                    <div class="table-responsive">
                      <table class="table">
                        
                        <thead>
                           <tr>
                            <form method="POST" action="<?php echo e(route('admin.customer.filter')); ?>">
                              <?php echo csrf_field(); ?>
                              <?php echo method_field('post'); ?>
                              
                              <td colspan="1"><input type="text" name="name" class="form-control" value="<?php if(isset($name)): ?> <?php echo e($name); ?> <?php echo e(old('name')); ?> <?php endif; ?>" placeholder="اسم العميل"></td>
                              <td colspan="1"><input type="email" name="email" class="form-control" value="<?php if(isset($email)): ?> <?php echo e($email); ?> <?php echo e(old('email')); ?> <?php endif; ?>" placeholder="البريد الالكتورني"></td>
                              <td colspan="2">
                                <select class="form-control" name="country">
                                  <option selected disabled>اختر الدولة</option>
                                  <?php if(isset($country)): ?>
                                    <?php if($country == "مصر"): ?>
                                      <option selected value="مصر">مصر</option>
                                    <?php else: ?>
                                      <option value="مصر">مصر</option>
                                    <?php endif; ?>
                                    <?php if($country == "السعودية"): ?>
                                      <option selected value="السعودية">السعودية</option>
                                    <?php else: ?>
                                      <option value="السعودية">السعودية</option>
                                    <?php endif; ?>
                                    <?php if($country == "قطر"): ?>
                                      <option selected value="قطر">قطر</option>
                                    <?php else: ?>
                                      <option value="قطر">قطر</option>
                                    <?php endif; ?>
                                  <?php else: ?>
                                    <option value="مصر">مصر</option>
                                    <option value="السعودية">السعودية</option>
                                    <option value="قطر">قطر</option>

                                  <?php endif; ?>
                                  
                                </select>
                              </td>
                              <td colspan="3">
                                <select class="form-control" name="status">
                                  <option selected disabled>اختر الحالة</option>
                                  <?php if(isset($status)): ?>
                                    <?php if($status == 1): ?>
                                      <option selected value="1">مفعل</option>
                                    <?php else: ?>
                                      <option value="1">مفعل</option>
                                    <?php endif; ?>
                                    <?php if($status == 0): ?>
                                      <option value="0" selected>غير مفعل</option>
                                    <?php else: ?>
                                      <option value="0">غير مفعل</option>
                                    <?php endif; ?>
                                  <?php else: ?>
                                    <option value="1">مفعل</option>
                                    <option value="0">غير مفعل</option>
                                  <?php endif; ?>
                                </select>
                              </td>
                              
                              
                              <td colspan="1"><input type="submit" class="btn btn-success w-100" value="بحث"></td>
                              <td colspan="1"><a href="<?php echo e(route('admin.customer')); ?>" class="btn btn-danger w-100" >X</a></td>
                            </form>

                          </tr>
                          <tr>
                              <td colspan="9"></td>
                              

                          </tr>
                          <tr>
                            <th>الاسم</th>
                            <th>البريد الالكتروني</th>
                            <th>الدولة</th>
                            <th>رقم الهاتف</th>
                            <th>تاريخ التفعيل</th>
                            <th colspan="4" class="text-center">الحالة</th>
                          </tr>
                        </thead>
                        <tbody>
                            <?php if(count($rows) > 0): ?>
                            <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <tr>
                                <td><?php echo e($row->name); ?></td>
                                <td><?php echo e($row->email); ?>	</td>
                                <td><?php echo e($row->country); ?>	</td>
                                <td><?php echo e($row->phone); ?>	</td>
                                <td>
                                  <?php if($row->agree_date != null): ?>
                                    <?php echo e($row->agree_date); ?>

                                  <?php else: ?>
                                    غير مفعل
                                  <?php endif; ?>
                                </td>
                                <td><a href="<?php echo e(route('admin.customer.show',$row->id)); ?>" class="btn btn-info"><i class="mdi mdi-eye  d-md-block pl-1"></i></a></td>
                                <td><a href="<?php echo e(route('admin.customer.comment',$row->id)); ?>" class="btn btn-primary">التعليق</a></td>
                                <td class="text-center" colspan="1">
                                  

                                    
                                  <form action="<?php echo e(route('admin.customer.update', $row->id )); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <?php if($row->status == 1): ?>
                                      <button type="submit" class="btn btn-success w-100">مفعل</i></button>
                                    <?php else: ?>
                                      <button type="submit" class="btn btn-danger w-100">غير مفعل</i></button>
                                    <?php endif; ?>
                                  </form>
                                </td>
                                <td class="text-center" colspan="1">
                                  <form action="<?php echo e(route('admin.customer.delete', $row->id )); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('POST'); ?>
                                      <button type="submit" class="btn btn-danger w-100">X</i></button>
                                   
                                  </form>
                                </td>
                                
                              </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          <?php else: ?>
                              <tr>
                                <td colspan="9" class="text-center">لا يوجد أى عميل</td>
                              </tr>
                          <?php endif; ?>
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              </div>
             <?php echo e($rows->links()); ?>

            </div>
          </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/goldenss/public_html/resources/views/admin/user/customer.blade.php ENDPATH**/ ?>