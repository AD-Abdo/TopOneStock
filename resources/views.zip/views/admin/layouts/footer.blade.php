<!-- content-wrapper ends -->
        <footer class="footer">
          <div class=" text-center">
            <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">كل الحقوق محفوظة لــ ©  <a
                href="{{ route('home') }}" target="_blank">GoldenSSM</a></span>
          </div>
        </footer>
